from django.shortcuts import render
from django.http import HttpResponse


#def index(request):
#    return HttpResponse("Hello from Notes app.")

# Create your views here.
#def index(request):
#    return render(request, "notes1/index.html") # request, hello/greet.html


#def home(request):
#    notes = ['Note1', 'Note2', 'Note3', 'Note4', 'Note5'] # our test data
#    return render (request, 'notes1/home.html', {'notes':notes})

def home(request):
    notes = [
        {'title': 'Note1', 'content': 'This is the first note.'},
        {'title': 'Note2', 'content': 'This is the second note.'},
        {'title': 'Note3', 'content': 'This is the third note.'},
        {'title': 'Note4', 'content': 'This is the third note.'},
        {'title': 'Note5', 'content': 'This is the third note.'},

    ]  # Тестові дані

    return render(request, 'notes1/home.html', {'notes': notes})